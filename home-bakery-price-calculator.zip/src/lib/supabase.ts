import { createClient, SupabaseClient } from '@supabase/supabase-js';

// Normalize URL in case user inputs https://xxxx.supabase.co/rest/v1/
const cleanUrl = (rawUrl: string) => {
  if (!rawUrl) return '';
  let url = rawUrl.trim();
  url = url.replace(/\/rest\/v1\/?$/, '');
  url = url.replace(/\/$/, '');
  return url;
};

const DEFAULT_SUPABASE_URL = 'https://qpkafzpvibqsuthzbiaa.supabase.co';
const DEFAULT_SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InFwa2FmenB2aWJxc3V0aHpiaWFhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODU4NTQ1MjUsImV4cCI6MjEwMTQzMDUyNX0.WlrZrV92oqD8T4UjDLZLKikWW0gZlnlwreJtRjTRd-Q';

const envUrl = cleanUrl(import.meta.env.VITE_SUPABASE_URL || DEFAULT_SUPABASE_URL);
const envAnonKey = (import.meta.env.VITE_SUPABASE_ANON_KEY || DEFAULT_SUPABASE_ANON_KEY).trim();

// Get stored credentials if available
export const getStoredCredentials = () => {
  const localUrl = cleanUrl(localStorage.getItem('supabase_url') || '');
  const localKey = (localStorage.getItem('supabase_anon_key') || '').trim();

  const url = envUrl || localUrl;
  const anonKey = envAnonKey || localKey;

  return { url, anonKey, isConfigured: Boolean(url && anonKey) };
};

export const isSupabaseConfigured = Boolean(
  (envUrl || localStorage.getItem('supabase_url')) &&
  (envAnonKey || localStorage.getItem('supabase_anon_key'))
);

let clientInstance: SupabaseClient | null = null;

export const getSupabaseClient = (): SupabaseClient | null => {
  const { url, anonKey, isConfigured } = getStoredCredentials();
  if (!isConfigured) {
    return null;
  }
  if (!clientInstance) {
    clientInstance = createClient(url, anonKey);
  }
  return clientInstance;
};

export const resetSupabaseClient = (url: string, anonKey: string) => {
  const normalizedUrl = cleanUrl(url);
  localStorage.setItem('supabase_url', normalizedUrl);
  localStorage.setItem('supabase_anon_key', anonKey.trim());
  clientInstance = createClient(normalizedUrl, anonKey.trim());
  return clientInstance;
};

