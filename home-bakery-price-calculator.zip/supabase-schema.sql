-- Supabase Schema Migration Script for Bakery Pre-Orders & Batches
-- Copy and paste this script into your Supabase Dashboard > SQL Editor > New Query

-- 1. Create Baking Batches Table
CREATE TABLE IF NOT EXISTS public.batches (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  baking_date DATE NOT NULL,
  notes TEXT,
  created_at BIGINT DEFAULT EXTRACT(EPOCH FROM NOW()) * 1000
);

-- 2. Create Orders Table
CREATE TABLE IF NOT EXISTS public.orders (
  id TEXT PRIMARY KEY,
  batch_id TEXT REFERENCES public.batches(id) ON DELETE SET NULL,
  customer_name TEXT NOT NULL,
  source TEXT CHECK (source IN ('whatsapp', 'instagram', 'other')),
  contact_detail TEXT,
  delivery_address TEXT,
  payment_method TEXT DEFAULT 'Transfer',
  payment_status TEXT CHECK (payment_status IN ('paid', 'unpaid')) DEFAULT 'unpaid',
  order_date DATE DEFAULT CURRENT_DATE,
  delivery_date DATE,
  notes TEXT,
  products JSONB DEFAULT '[]'::jsonb,
  total_amount NUMERIC(12, 2) DEFAULT 0,
  created_at BIGINT DEFAULT EXTRACT(EPOCH FROM NOW()) * 1000
);

-- 3. Enable Row Level Security (RLS) - Optional public read/write policy for simple setups
ALTER TABLE public.batches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access to batches" ON public.batches FOR SELECT USING (true);
CREATE POLICY "Allow public insert/update/delete access to batches" ON public.batches FOR ALL USING (true);

CREATE POLICY "Allow public read access to orders" ON public.orders FOR SELECT USING (true);
CREATE POLICY "Allow public insert/update/delete access to orders" ON public.orders FOR ALL USING (true);
